; --- SEGMENT 1 ---
lui x1, 0xFF004
lui x2, 0xFF004
lui x3, 0x1
lui x4, 0x1
lui x5, 0xF4000
lui x6, 0xF4200
lui x7, 0xF4000
lui x8, 0xF4200
addi x1, x1, 0x400
addi x2, x2, 0x440
addi x3, x3, 0x8
addi x4, x4, 0x0
addi x5, x5, 0x500
addi x6, x6, 0x500
addi x7, x7, 0x5C0
addi x8, x8, 0x5C0
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
lp.setup x1, 0x62
lbu x9, 0xD(x1)
addi x0, x0, 0
addi x0, x0, 0
addi x0, x0, 0
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0
beq x9, x3, 0x0
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0
addi x0, x0, 0 
addi x0, x0, 0
add x1, x1, x2 
addi x0, x0, 0
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0
addi x0, x0, 0 
addi x0, x0, 0
beq x9, x4, 0x0
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
lp.goto x1, -0x10
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0


