; --- SEGMENT 1 ---
lui x1, 0xFF004
lui x2, 0xFF004
lui x3, 0x1
lui x4, 0x1
lui x5, 0xF4000
lui x6, 0xF4200
lui x7, 0xF4000
lui x8, 0xF4200
lui x11, 0xFF005
lui x12, 0x0
lui  x13, 0x00001
lui  x14, 0x00001
addi x1, x1, 0x400
addi x2, x2, 0x440
addi x3, x3, 0x8
addi x4, x4, 0x0
addi x5, x5, 0x0
addi x6, x6, 0x0
addi x7, x7, 0x200
addi x8, x8, 0x200
addi x11, x11, 0x0
addi x12, x12, 0x4
addi x13, x13, 0x008     
addi x14, x14, 0x000

addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 

addi x0, x0, 0 
addi x0, x0, 0 
sw x3,  0x0(x2)
addi x0, x0, 0

addi x0, x0, 0 
addi x0, x0, 0 
sw x4, 0x4(x2)
addi x0, x0, 0

addi x0, x0, 0 
addi x0, x0, 0 
sw x6, 0x8(x2)
addi x0, x0, 0 

addi x0, x0, 0 
addi x0, x0, 0  
sw x8, 0x10(x2)
addi x0, x0, 0 

addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
lp.setup  x1, 1

addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 

addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
lp.goto x1, -0x10

addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0

addi x0, x0, 0 
addi x0, x0, 0 
sw x3,  0x0(x1) 
addi x0, x0, 0

addi x0, x0, 0 
addi x0, x0, 0 
sw x4, 0x4(x1)
addi x0, x0, 0

addi x0, x0, 0 
addi x0, x0, 0           
sw x5, 0x8(x1)   
addi x0, x0, 0

addi x0, x0, 0 
addi x0, x0, 0 
sw x7, 0x10(x1) 
addi x0, x0, 0

addi x0, x0, 0 
addi x0, x0, 0 
sw x12, 0x0(x11) 
addi x0, x0, 0

addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
lp.setup  x1, 1000

addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 

addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
lp.goto x1, -0x10

addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0
; --- SEGMENT 2 ---
lui x1, 0xFF000
lui x2, 0xFF000
lui x3, 0xF4400
lui x4, 0xF4600
lui x5, 0x1
lui x6, 0x1
lui x7, 0xF4401
lui x8, 0xF4601
lui x9, 0xF4401
lui x10, 0xF4601
lui x11, 0xF4403
lui x12, 0xF4603
addi x1, x1, 0x0
addi x2, x2, 0x400
addi x3, x3, 0x0
addi x4, x4, 0x0
addi x5, x5, 0x1
addi x6, x6, 0x0
addi x7, x7, 0x400
addi x8, x8, 0x400
addi x9, x9, 0x440
addi x10, x10, 0x440
addi x11, x11, 0x840
addi x12, x12, 0x840
addi x0, x0, 0
addi x0, x0, 0 
addi x0, x0, 0
addi x0, x0, 0 

addi x0, x0, 0
sw x6, 0x34(x1)
addi x0, x0, 0 
addi x0, x0, 0
addi x0, x0, 0 
sw x3,  0x38(x1)
addi x0, x0, 0 
addi x0, x0, 0
addi x0, x0, 0
sw x5, 0x30(x1)
addi x0, x0, 0 
addi x0, x0, 0
addi x0, x0, 0
sw x7, 0x40(x1) 
addi x0, x0, 0 
addi x0, x0, 0 

addi x0, x0, 0 
sw x6, 0x4(x1)
addi x0, x0, 0
addi x0, x0, 0
addi x0, x0, 0 
sw x9,  0x8(x1)
addi x0, x0, 0 
addi x0, x0, 0
addi x0, x0, 0
sw x5, 0x0(x1) 
addi x0, x0, 0
addi x0, x0, 0
addi x0, x0, 0 
sw x11, 0x10(x1)
addi x0, x0, 0
addi x0, x0, 0



addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
lp.setup  x1, 20
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 

addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
lp.goto x1, -0x10
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 

addi x0, x0, 0 
sw x6, 0x34(x2)
addi x0, x0, 0
addi x0, x0, 0
addi x0, x0, 0 
sw x4,  0x38(x2)
addi x0, x0, 0 
addi x0, x0, 0
addi x0, x0, 0
sw x5, 0x30(x2) 
addi x0, x0, 0
addi x0, x0, 0
addi x0, x0, 0 
sw x8, 0x40(x2)
addi x0, x0, 0
addi x0, x0, 0

addi x0, x0, 0
sw x6, 0x4(x2)
addi x0, x0, 0 
addi x0, x0, 0
addi x0, x0, 0 
sw x10,  0x8(x2)
addi x0, x0, 0 
addi x0, x0, 0
addi x0, x0, 0
sw x5, 0x0(x2)
addi x0, x0, 0 
addi x0, x0, 0
addi x0, x0, 0
sw x12, 0x10(x2) 
addi x0, x0, 0 
addi x0, x0, 0

addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
lp.setup  x2, 100
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
lp.goto x1, -0x10
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 
addi x0, x0, 0 


 
