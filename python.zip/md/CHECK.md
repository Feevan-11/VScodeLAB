| PC       | Slot3              | Slot2              | Slot1              | Slot0               |
|----------|--------------------|--------------------|--------------------|---------------------|
| `0x0000` | `lui x1, 0x0`      | `lui x2, 0x0`      | `lui x3, 0x0`      | `lui x4, 0x0`       |
| `0x0010` | `lui x5, 0x0`      | `lui x6, 0x0`      | `lui x7, 0x0`      | `lui x8, 0x0`       |
| `0x0020` | `addi x1, x1, 0x0` | `addi x2, x2, 0x0` | `addi x3, x3, 0x0` | `addi x4, x4, 0x0`  |
| `0x0030` | `addi x5, x5, 0x0` | `addi x6, x6, 0x0` | `addi x7, x7, 0x0` | `addi x8, x8, 0x0`  |
| `0x0040` | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `lp.setup x1, 0x62` |
| `0x0050` | `lbu x9, 0xD(x1)`  | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `addi x0, x0, 0`    |
| `0x0060` | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `beq x9, x3, 0x0`   |
| `0x0070` | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `addi x0, x0, 0`    |
| `0x0080` | `addi x0, x0, 0`   | `add x1, x1, x2`   | `addi x0, x0, 0`   | `addi x0, x0, 0`    |
| `0x0090` | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `addi x0, x0, 0`    |
| `0x00A0` | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `beq x9, x4, 0x0`   |
| `0x00B0` | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `lp.goto x1, -0x10` |
| `0x00C0` | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `addi x0, x0, 0`   | `addi x0, x0, 0`    |