| PC       | Slot3                  | Slot2                  | Slot1                  | Slot0                  |
|----------|------------------------|------------------------|------------------------|------------------------|
| `0x0000` | `lui  x1, 0xC0001`     | `lui  x2, 0xC0001`     | `lui  x3, 0x00001`     | `lui  x4, 0x00001`     |
| `0x0010` | `lui  x5, 0x00000`     | `lui  x6, 0xA8000`     | `lui  x7, 0x40000`     | `lui  x8, 0xB0001`     |
| `0x0020` | `addi x1, x1, 0x800`   | `addi x2, x2, 0x840`   | `addi x3, x3, 0x000`   | `addi x4, x4, 0x000`   |
| `0x0030` | `addi x5, x5, 0x000`   | `addi x6, x6, 0x000`   | `addi x7, x7, 0x000`   | `addi x8, x8, 0x000`   |
| `0x0040` | `lui  x9, 0x00000`     | `sw x3,  0x0(x2)`      | `sw x3,  0x0(x1)`      | `lui  x10, 0x00001`    |
| `0x0050` | `addi x0, x0, 0`       | `sw x4, 0x4(x2)`       | `sw x4, 0x4(x1)`       | `addi x0, x0, 0`       |
| `0x0060` | `addi x9, x9, 0x40`    | `sw x7, 0x18(x2)`      | `sw x5, 0x18(x1)`      | `addi x10, x10, 0x800` |
| `0x0070` | `addi x0, x0, 0`       | `sw x8, 0x20(x2)`      | `sw x6, 0x20(x1)`      | `addi x0, x0, 0`       |
| `0x0080` | `addi x0, x0, 0`       | `sw x10, 0x28(x2)`     | `sw x9, 0x28(x1)`      | `addi x0, x0, 0`       |
| `0x0090` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `lp.setup  x1,  80`    |
| `0x00A0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       |
| `0x00B0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `lp.goto x1, -0x10`    |
| `0x00C0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       |
| `0x00D0` | `lui  x11, 0x00000`    | `lui  x12, 0xAC000`    | `lui  x13, 0x00000`    | `lui  x14, 0x00000`    |
| `0x00E0` | `lui  x15, 0xA0000`    | `lui  x16, 0x00000`    | `lui  x17, 0x00000`    | `lui  x18, 0xA4000`    |
| `0x00F0` | `addi x11, x11, 0x040` | `addi x12, x12, 0x000` | `addi x13, x13, 0x040` | `addi x14, x14, 0x080` |
| `0x0100` | `addi x15, x15, 0x000` | `addi x16, x16, 0x080` | `addi x17, x17, 0x100` | `addi x18, x18, 0x000` |
| `0x0110` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x3, 0x0(x1)`       | `addi x0, x0, 0`       |
| `0x0120` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x4, 0x4(x1)`       | `addi x0, x0, 0`       |
| `0x0130` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x11, 0x18(x1)`     | `addi x0, x0, 0`       |
| `0x0140` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x12, 0x20(x1)`     | `addi x0, x0, 0`       |
| `0x0150` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x13, 0x28(x1)`     | `addi x0, x0, 0`       |
| `0x0160` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `lp.setup  x1,  80`    |
| `0x0170` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       |
| `0x0180` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `lp.goto x1, -0x10`    |
| `0x0190` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       |
| `0x01A0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x3, 0x0(x1)`       | `addi x0, x0, 0`       |
| `0x01B0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x4, 0x4(x1)`       | `addi x0, x0, 0`       |
| `0x01C0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x14, 0x18(x1)`     | `addi x0, x0, 0`       |
| `0x01D0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x15, 0x20(x1)`     | `addi x0, x0, 0`       |
| `0x01E0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x16, 0x28(x1)`     | `addi x0, x0, 0`       |
| `0x01F0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `lp.setup  x1,  80`    |
| `0x0200` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       |
| `0x0210` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `lp.goto x1, -0x10`    |
| `0x0220` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       |
| `0x0230` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x3, 0x0(x1)`       | `addi x0, x0, 0`       |
| `0x0240` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x4, 0x4(x1)`       | `addi x0, x0, 0`       |
| `0x0250` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x17, 0x18(x1)`     | `addi x0, x0, 0`       |
| `0x0260` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x18, 0x20(x1)`     | `addi x0, x0, 0`       |
| `0x0270` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `sw x16, 0x28(x1)`     | `addi x0, x0, 0`       |
| `0x0280` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `lp.setup  x1,  80`    |
| `0x0290` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       |
| `0x02A0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `lp.goto x1, -0x10`    |
| `0x02B0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       |
| `0x02C0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `lp.setup  x1, 50`     |
| `0x02D0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       |
| `0x02E0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `lp.goto x1, 0xD20`    |
| `0x02F0` | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       | `addi x0, x0, 0`       |